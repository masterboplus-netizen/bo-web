export function initFloatingMenu() {
    const capsule = document.getElementById('floating-capsule');
    if (!capsule) return;

    let isDragging = false;
    let startY = 0;
    let startTop = 0;

    capsule.addEventListener('touchstart', (e) => {
        isDragging = true;
        startY = e.touches[0].clientY;
        startTop = capsule.getBoundingClientRect().top;
    });

    capsule.addEventListener('touchmove', (e) => {
        if (!isDragging) return;
        const currentY = e.touches[0].clientY;
        const deltaY = currentY - startY;
        const newTop = startTop + deltaY;
        
        const minTop = 80;
        const maxTop = window.innerHeight - 200;
        
        if (newTop > minTop && newTop < maxTop) {
            capsule.style.bottom = 'auto';
            capsule.style.top = newTop + 'px';
        }
    });

    capsule.addEventListener('touchend', () => {
        isDragging = false;
    });

    capsule.addEventListener('mousedown', (e) => {
        isDragging = true;
        startY = e.clientY;
        startTop = capsule.getBoundingClientRect().top;
    });

    window.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        const currentY = e.clientY;
        const deltaY = currentY - startY;
        const newTop = startTop + deltaY;

        const minTop = 80;
        const maxTop = window.innerHeight - 200;

        if (newTop > minTop && newTop < maxTop) {
            capsule.style.bottom = 'auto';
            capsule.style.top = newTop + 'px';
        }
    });

    window.addEventListener('mouseup', () => {
        isDragging = false;
    });
}
